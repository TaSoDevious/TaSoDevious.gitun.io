# Wild Neighbors Website

Upload every file in this folder to one GitHub repository. The home page is `index.html`.

To publish with GitHub Pages: open the repository **Settings**, select **Pages**, choose **Deploy from a branch**, select `main` and `/ (root)`, then save. GitHub will give you a website link to submit.

Before submitting, replace `Monta` in the HTML/CSS/JS comments and the example email address with your own name and email if needed.
